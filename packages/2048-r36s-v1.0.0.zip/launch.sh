#!/bin/sh
cd "$(dirname "$0")"
exec ./bin/2048 "$@"
