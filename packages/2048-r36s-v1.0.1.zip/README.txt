2048 for R36S. Use the D-pad to move tiles; A restarts; B exits.
