Snake for R36S. Controls: D-pad; B exits where supported.
